#!/bin/bash
echo "Omar Sayed Hashem"
rm -r Lab1
mkdir Lab1
cd Lab1
cp  ../../Desktop/words.txt words.txt
cp  ../../Desktop/numbers.txt numbers.txt
paste words.txt numbers.txt > MergedContent.txt
head -n3 MergedContent.txt
sort MergedContent.txt > SortedMergedContent.txt
echo The sorted file is:
cat SortedMergedContent.txt
chmod 333 SortedMergedContent.txt
sort -u MergedContent.txt
cat SortedMergedContent.txt | tr '[a-z]' '[A-Z]' > CapitalSortedMergedContent.txt
echo "because we don't have the permissions"
chmod 777 SortedMergedContent.txt
cat SortedMergedContent.txt | tr '[a-z]' '[A-Z]' > CapitalSortedMergedContent.txt
cat SortedMergedContent.txt | grep -n "^w.*[0-9]$"
cat SortedMergedContent.txt | tr i o > NewMergedContent.txt
paste SortedMergedContent.txt NewMergedContent.txt
