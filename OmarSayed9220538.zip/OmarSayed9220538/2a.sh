#!/bin/bash
function convert {
    mod=1
    if [ "$#" -gt 1 ]; then
        mod=$1
        num=$2
    else
        num=$1
    fi

    if [ $mod -eq 1 ]; then
        res=0
        len=${#num}
        for ((i = 0; i < len; i++)); do
            bit=${num:i:1}
            (( res = res * 2 + bit ))
        done
    elif [ $num -eq 0 ]; then
        res=0
    else
        res=""
        until [ $num -eq 0 ]; do
            bit=$(( num % 2 ))
            (( num = num / 2 ))
            res="$bit$res"
        done
    fi

    echo $res
}

convert 1 10010
convert 2 5
convert 01100
convert 101010101011100100010101010110011
convert 2 15
convert 2 16
convert 2 1
convert 2 0
convert 101011
convert 1 101011
convert 1 0
convert 0

