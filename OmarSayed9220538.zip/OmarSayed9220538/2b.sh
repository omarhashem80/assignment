#!/bin/bash
function checkPal {
text=$(echo "$1" | tr '[:upper:]' '[:lower:]')
len=${#text};
((l = len - 1 ))
((len = len / 2 ))
res=1
for (( i=0 ; i<len ; i++ )) do
if [ ${text:i:1} != ${text:l-i:1} ]; then
res=0
break;
fi
done
echo $res
}


checkPal apple
checkPal Amenicycinema
checkPal LevEL
checkPal L
checkPal alaa
checkPal mama
checkPal omamo
